package codedna;

public class SVGBuilder {

    private static final int CX = 400; // SVG center X
    private static final int CY = 350; // SVG center Y

    public static String build(CreatureGenerator.Creature c) {
        StringBuilder svg = new StringBuilder();

        svg.append("<svg id='creature-svg' viewBox='0 0 800 700' xmlns='http://www.w3.org/2000/svg'>\n");
        svg.append(buildAura(c));
        svg.append(buildCells(c));
        svg.append(buildBody(c));
        svg.append(buildMutations(c));
        svg.append(buildNucleus(c));
        svg.append(buildLabel(c));
        svg.append("</svg>\n");

        return svg.toString();
    }

    // ── Outer aura ring (health halo) — static, no animation ────
    private static String buildAura(CreatureGenerator.Creature c) {
        return String.format(
                "<circle cx='%d' cy='%d' r='%d' fill='none' stroke='%s' stroke-width='3' opacity='%.2f'/>\n",
                CX, CY, c.auraRadius, c.auraColor, c.auraOpacity
        );
    }

    // ── Cells (loops / ifs) — static dots at fixed positions ────
    private static String buildCells(CreatureGenerator.Creature c) {
        StringBuilder sb = new StringBuilder();
        for (CreatureGenerator.Cell cell : c.cells) {
            sb.append(String.format(
                    "<circle cx='%.1f' cy='%.1f' r='%d' fill='%s' opacity='0.85'/>\n",
                    CX + cell.cx, CY + cell.cy, cell.radius, cell.color
            ));
        }
        return sb.toString();
    }

    // ── Main body (organism blob) — static circle ────────────────
    private static String buildBody(CreatureGenerator.Creature c) {
        return String.format(
                "<circle cx='%d' cy='%d' r='%d' fill='%s' stroke='%s' stroke-width='1.5'/>\n",
                CX, CY, c.bodyRadius, c.bodyColor, c.bodyGlow
        );
    }

    // ── Mutations (nested loops) — static warning dots ───────────
    private static String buildMutations(CreatureGenerator.Creature c) {
        StringBuilder sb = new StringBuilder();
        for (CreatureGenerator.Mutation mu : c.mutations) {
            sb.append(String.format(
                    "<circle cx='%.1f' cy='%.1f' r='%d' fill='%s' opacity='0.75'/>\n",
                    CX + mu.cx, CY + mu.cy, mu.size, mu.color
            ));
        }
        return sb.toString();
    }

    // ── Nucleus (class core) — static circle ──────────────────────
    private static String buildNucleus(CreatureGenerator.Creature c) {
        return String.format(
                "<circle cx='%d' cy='%d' r='%d' fill='%s'/>\n",
                CX, CY, c.nucleusRadius, c.nucleusColor
        );
    }

    // ── Creature name label ────────────────────────────────────
    private static String buildLabel(CreatureGenerator.Creature c) {
        return String.format(
                "<text x='%d' y='%d' text-anchor='middle' font-family='monospace' font-size='14' fill='%s'>%s</text>\n",
                CX, CY + c.bodyRadius + 30, c.bodyGlow, c.name
        );
    }
}