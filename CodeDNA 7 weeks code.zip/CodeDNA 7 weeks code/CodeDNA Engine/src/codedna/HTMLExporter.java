package codedna;

import java.io.*;
import java.nio.file.*;

public class HTMLExporter {

    public static String export(
            ASTParser.CodeMetrics metrics,
            CreatureGenerator.Creature creature,
            String svgContent,
            String outputPath) throws IOException {

        String html = buildHTML(metrics, svgContent);
        Files.writeString(Paths.get(outputPath), html);
        return outputPath;
    }

    private static String buildHTML(ASTParser.CodeMetrics m, String svg) {
        StringBuilder html = new StringBuilder();
        html.append("<!DOCTYPE html>\n<html lang='en'>\n<head>\n");
        html.append("<meta charset='UTF-8'>\n");
        html.append("<title>CodeDNA — ").append(m.fileName).append("</title>\n");
        html.append("<style>\n");
        html.append("body{margin:0;background:#0b0f1a;display:flex;align-items:center;justify-content:center;min-height:100vh;font-family:monospace}\n");
        html.append("svg{width:90%;max-width:600px;height:auto}\n");
        html.append("</style>\n</head>\n<body>\n");
        html.append(svg);
        html.append("\n</body>\n</html>");
        return html.toString();
    }
}