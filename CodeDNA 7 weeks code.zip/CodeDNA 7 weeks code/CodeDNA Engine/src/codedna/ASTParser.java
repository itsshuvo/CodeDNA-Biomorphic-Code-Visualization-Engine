package codedna;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

public class ASTParser {

    // ── Result container ──────────────────────────────────────
    public static class CodeMetrics {
        public String fileName;
        public List<String> classNames    = new ArrayList<>();
        public List<String> methodNames   = new ArrayList<>();
        public int totalLines;
        public int codeLines;
        public int commentLines;
        public int blankLines;
        public int methodCount;
        public int classCount;
        public int loopCount;       // for, while, do-while
        public int nestedLoopCount; // loops inside loops
        public int ifCount;
        public int tryCount;
        public int importCount;
        public int complexityScore; // 0–100
        public int healthScore;     // 0–100 (clean code indicator)
        public List<String> keywords = new ArrayList<>();
        public Map<String, Integer> methodLineCounts = new LinkedHashMap<>();
    }

    // ── Main parse entry point ─────────────────────────────────
    public static CodeMetrics parse(String filePath) throws IOException {
        CodeMetrics m = new CodeMetrics();
        m.fileName = Paths.get(filePath).getFileName().toString();

        List<String> lines = Files.readAllLines(Paths.get(filePath));
        m.totalLines = lines.size();

        boolean inBlockComment = false;
        String currentMethod   = null;
        int    methodLineStart = 0;
        int    braceDepth      = 0;
        int    loopDepthMax    = 0;
        int    currentLoopDepth = 0;

        // Regex patterns
        Pattern classPattern  = Pattern.compile("\\b(class|interface|enum)\\s+(\\w+)");
        Pattern methodPattern = Pattern.compile(
                "\\b(public|private|protected|static|void|int|String|boolean|double|float|long)\\b.*\\b(\\w+)\\s*\\(.*\\)\\s*\\{?");
        Pattern loopPattern   = Pattern.compile("\\b(for|while|do)\\b");
        Pattern ifPattern     = Pattern.compile("\\bif\\s*\\(");
        Pattern tryPattern    = Pattern.compile("\\btry\\s*\\{");
        Pattern importPattern = Pattern.compile("^\\s*import\\s+");

        for (String raw : lines) {
            String line = raw.trim();

            // ── Count line types ──────────────────────────────
            if (line.isEmpty()) {
                m.blankLines++;
                continue;
            }
            if (inBlockComment) {
                m.commentLines++;
                if (line.contains("*/")) inBlockComment = false;
                continue;
            }
            if (line.startsWith("//")) {
                m.commentLines++;
                continue;
            }
            if (line.startsWith("/*") || line.startsWith("/**")) {
                m.commentLines++;
                if (!line.contains("*/")) inBlockComment = true;
                continue;
            }
            m.codeLines++;

            // ── Classes ───────────────────────────────────────
            Matcher cm = classPattern.matcher(line);
            if (cm.find()) {
                m.classCount++;
                m.classNames.add(cm.group(2));
            }

            // ── Methods ───────────────────────────────────────
            Matcher mm = methodPattern.matcher(line);
            if (mm.find() && line.contains("(") && line.contains(")") && !line.startsWith("//")) {
                String mName = mm.group(2);
                // filter out keywords that look like methods
                if (!mName.equals("if") && !mName.equals("while") && !mName.equals("for")
                        && !mName.equals("switch") && !mName.equals("catch") && !mName.equals("class")) {
                    if (currentMethod != null) {
                        m.methodLineCounts.put(currentMethod, m.codeLines - methodLineStart);
                    }
                    currentMethod  = mName;
                    methodLineStart = m.codeLines;
                    m.methodCount++;
                    m.methodNames.add(mName);
                }
            }

            // ── Loops ─────────────────────────────────────────
            Matcher lm = loopPattern.matcher(line);
            if (lm.find()) {
                m.loopCount++;
                currentLoopDepth++;
                loopDepthMax = Math.max(loopDepthMax, currentLoopDepth);
            }

            // ── Nested loops ──────────────────────────────────
            long openBraces  = line.chars().filter(c -> c == '{').count();
            long closeBraces = line.chars().filter(c -> c == '}').count();
            braceDepth += openBraces - closeBraces;
            if (closeBraces > 0 && currentLoopDepth > 0) currentLoopDepth--;

            // ── Ifs / try ─────────────────────────────────────
            if (ifPattern.matcher(line).find())  m.ifCount++;
            if (tryPattern.matcher(line).find()) m.tryCount++;

            // ── Imports ───────────────────────────────────────
            if (importPattern.matcher(line).find()) m.importCount++;
        }

        // ── Save last method ──────────────────────────────────
        if (currentMethod != null) {
            m.methodLineCounts.put(currentMethod, m.codeLines - methodLineStart);
        }

        // ── Nested loop count ─────────────────────────────────
        m.nestedLoopCount = Math.max(0, loopDepthMax - 1);

        // ── Complexity score (0–100) ──────────────────────────
        int complexity = 0;
        complexity += Math.min(30, m.methodCount * 3);
        complexity += Math.min(20, m.loopCount   * 4);
        complexity += Math.min(20, m.ifCount      * 2);
        complexity += Math.min(15, m.nestedLoopCount * 10);
        complexity += Math.min(10, m.classCount   * 5);
        complexity += Math.min(5,  m.tryCount     * 2);
        m.complexityScore = Math.min(100, complexity);

        // ── Health score (0–100) ──────────────────────────────
        // Higher comment ratio = healthier, lower nested loops = healthier
        int health = 60;
        if (m.totalLines > 0) {
            double commentRatio = (double) m.commentLines / m.totalLines;
            health += (int)(commentRatio * 30);
        }
        health -= m.nestedLoopCount * 8;
        health -= Math.max(0, m.methodCount - 10) * 2;
        m.healthScore = Math.max(5, Math.min(100, health));

        // ── Top keywords ──────────────────────────────────────
        m.keywords = extractKeywords(lines);

        return m;
    }

    // ── Extract most-used identifiers ─────────────────────────
    private static List<String> extractKeywords(List<String> lines) {
        Map<String, Integer> freq = new HashMap<>();
        Pattern word = Pattern.compile("\\b([a-zA-Z][a-zA-Z0-9]{3,})\\b");
        Set<String> skip = new HashSet<>(Arrays.asList(
                "public","private","protected","static","void","class",
                "return","import","package","this","super","new","null",
                "true","false","else","extends","implements","interface",
                "final","abstract","String","List","Map","int","boolean"
        ));
        for (String line : lines) {
            Matcher m = word.matcher(line.trim());
            while (m.find()) {
                String w = m.group(1);
                if (!skip.contains(w)) freq.merge(w, 1, Integer::sum);
            }
        }
        return freq.entrySet().stream()
                .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
                .limit(6)
                .map(Map.Entry::getKey)
                .collect(java.util.stream.Collectors.toList());
    }
}
