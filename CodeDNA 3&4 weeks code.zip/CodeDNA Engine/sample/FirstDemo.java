public class FirstDemo {

    public static void main(String[] args) {
        System.out.println("Hello from FirstDemo!");
        printNumbers();
        checkGrades();
    }

    public static void printNumbers() {
        for (int i = 1; i <= 5; i++) {
            System.out.println("Number: " + i);
        }
    }

    public static void checkGrades() {
        int[] grades = {85, 92, 40, 70, 55};
        for (int grade : grades) {
            if (grade >= 90) {
                System.out.println("Excellent");
            } else if (grade >= 70) {
                System.out.println("Good");
            } else {
                System.out.println("Needs Improvement");
            }
        }
    }
}