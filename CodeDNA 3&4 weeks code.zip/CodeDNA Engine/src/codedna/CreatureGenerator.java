package codedna;

public class CreatureGenerator {
}
