package codedna;

public class Main {
    public static void main(String[] args) throws Exception {
        String filePath = "sample/FirstDemo.java";

        ASTParser.CodeMetrics m = ASTParser.parse(filePath);

        System.out.println("===== CodeDNA Parser Results =====");
        System.out.println("File            : " + m.fileName);
        System.out.println("Total Lines     : " + m.totalLines);
        System.out.println("Code Lines      : " + m.codeLines);
        System.out.println("Comment Lines   : " + m.commentLines);
        System.out.println("Blank Lines     : " + m.blankLines);
        System.out.println("----------------------------------");
        System.out.println("Classes         : " + m.classCount + " " + m.classNames);
        System.out.println("Methods         : " + m.methodCount + " " + m.methodNames);
        System.out.println("Loops           : " + m.loopCount);
        System.out.println("Nested Loops    : " + m.nestedLoopCount);
        System.out.println("If Statements   : " + m.ifCount);
        System.out.println("Try Blocks      : " + m.tryCount);
        System.out.println("Imports         : " + m.importCount);
        System.out.println("----------------------------------");
        System.out.println("Complexity Score: " + m.complexityScore + "/100");
        System.out.println("Health Score    : " + m.healthScore + "/100");
        System.out.println("Top Keywords    : " + m.keywords);
        System.out.println("==================================");
    }
}