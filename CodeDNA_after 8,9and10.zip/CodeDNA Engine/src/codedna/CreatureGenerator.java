package codedna;

import java.util.*;

public class CreatureGenerator {

    // ── Creature data model ───────────────────────────────────
    public static class Creature {
        // Body
        public int    bodyRadius;       // 40–120
        public String bodyColor;
        public String bodyGlow;
        public double pulseSpeed;       // animation duration in seconds

        // Nucleus (main class core)
        public int    nucleusRadius;
        public String nucleusColor;

        // Tentacles (methods)
        public List<Tentacle> tentacles = new ArrayList<>();

        // Cells (loops / ifs)
        public List<Cell> cells = new ArrayList<>();

        // Mutations (nested loops = bad code)
        public List<Mutation> mutations = new ArrayList<>();

        // Aura (health ring)
        public String auraColor;
        public int    auraRadius;
        public double auraOpacity;

        // Metadata
        public String name;
        public int    complexityScore;
        public int    healthScore;
        public String personality;  // "Elegant", "Chaotic", "Warrior", etc.
        public String description;
        public List<String> traits = new ArrayList<>();

        // ── Added for Week 6 console reporting ──────────────
        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("===== Creature Profile =====\n");
            sb.append("Name          : ").append(name).append("\n");
            sb.append("Personality   : ").append(personality).append("\n");
            sb.append("Description   : ").append(description).append("\n");
            sb.append("Health Score  : ").append(healthScore).append("/100\n");
            sb.append("Complexity    : ").append(complexityScore).append("/100\n");
            sb.append("Body Radius   : ").append(bodyRadius).append("  Color: ").append(bodyColor).append("\n");
            sb.append("Nucleus       : radius ").append(nucleusRadius).append(", color ").append(nucleusColor).append("\n");
            sb.append("Tentacles     : ").append(tentacles.size()).append(" (methods)\n");
            sb.append("Cells         : ").append(cells.size()).append(" (loops + ifs)\n");
            sb.append("Mutations     : ").append(mutations.size()).append(" (nested loops)\n");
            sb.append("Traits        : ").append(traits).append("\n");
            sb.append("=============================\n");
            return sb.toString();
        }
    }

    public static class Tentacle {
        public double angle;       // radians
        public int    length;      // 60–180
        public int    thickness;   // 2–8
        public String color;
        public String methodName;
        public int    methodLines;
        public double waveSpeed;
    }

    public static class Cell {
        public double cx, cy;      // relative to center
        public int    radius;      // 4–14
        public String color;
        public String type;        // "loop", "if", "try"
        public double orbitSpeed;
        public double orbitRadius;
        public double orbitAngle;
    }

    public static class Mutation {
        public double cx, cy;
        public int    size;
        public String color;
        public double pulseSpeed;
    }

    // ── Main generation ───────────────────────────────────────
    public static Creature generate(ASTParser.CodeMetrics m) {
        Creature c = new Creature();
        Random rng = new Random(m.fileName.hashCode()); // deterministic per file

        c.name            = m.fileName.replace(".java", "");
        c.complexityScore = m.complexityScore;
        c.healthScore     = m.healthScore;

        // ── Body size from line count ─────────────────────────
        c.bodyRadius = clamp(40 + m.codeLines / 8, 55, 120);

        // ── Colors from health ────────────────────────────────
        if (m.healthScore >= 75) {
            // Healthy → blue/cyan
            c.bodyColor  = "rgba(30,120,220,0.85)";
            c.bodyGlow   = "#3d9fff";
            c.auraColor  = "#00e5ff";
            c.personality = "Elegant";
            c.description = "A well-structured, healthy organism. Clean code flows through every cell.";
        } else if (m.healthScore >= 45) {
            // Average → green/yellow
            c.bodyColor  = "rgba(40,160,80,0.85)";
            c.bodyGlow   = "#00ff9f";
            c.auraColor  = "#aaff44";
            c.personality = "Warrior";
            c.description = "A resilient organism, battle-tested. Some scars, but functional.";
        } else {
            // Unhealthy → red/orange
            c.bodyColor  = "rgba(180,40,60,0.85)";
            c.bodyGlow   = "#ff4060";
            c.auraColor  = "#ff8800";
            c.personality = "Chaotic";
            c.description = "A mutating organism under stress. Nested complexity strains its DNA.";
        }

        // ── Nucleus from class count ──────────────────────────
        c.nucleusRadius = clamp(10 + m.classCount * 6, 12, 40);
        c.nucleusColor  = m.classCount > 3 ? "#ffe066" : "#ffffff";

        // ── Aura ──────────────────────────────────────────────
        c.auraRadius  = c.bodyRadius + 25;
        c.auraOpacity = 0.15 + (m.healthScore / 200.0);

        // ── Pulse speed (complex = fast/erratic) ──────────────
        c.pulseSpeed = 4.0 - (m.complexityScore / 50.0);
        c.pulseSpeed = Math.max(1.5, Math.min(4.0, c.pulseSpeed));

        // ── Tentacles (one per method, max 16) ───────────────
        int tentacleCount = Math.min(m.methodNames.size(), 16);
        for (int i = 0; i < tentacleCount; i++) {
            Tentacle t   = new Tentacle();
            t.angle      = (2 * Math.PI / tentacleCount) * i;
            String mName = m.methodNames.get(i);
            int mLines   = m.methodLineCounts.getOrDefault(mName, 10);
            t.length     = clamp(60 + mLines * 2, 60, 200);
            t.thickness  = clamp(2 + mLines / 10, 2, 9);
            t.methodName = mName;
            t.methodLines = mLines;
            t.waveSpeed  = 1.5 + rng.nextDouble() * 3;

            // Color by method complexity
            if (mLines > 40)       t.color = "#ff6b6b";
            else if (mLines > 20)  t.color = "#ffd93d";
            else                   t.color = c.auraColor;

            c.tentacles.add(t);
        }

        // ── Cells (orbiting — one per loop/if) ────────────────
        int cellCount = Math.min(m.loopCount + m.ifCount, 20);
        for (int i = 0; i < cellCount; i++) {
            Cell cell       = new Cell();
            cell.orbitRadius = c.bodyRadius + 15 + rng.nextInt(50);
            cell.orbitAngle  = (2 * Math.PI / Math.max(1, cellCount)) * i + rng.nextDouble();
            cell.cx          = Math.cos(cell.orbitAngle) * cell.orbitRadius;
            cell.cy          = Math.sin(cell.orbitAngle) * cell.orbitRadius;
            cell.radius      = 4 + rng.nextInt(8);
            cell.orbitSpeed  = 3 + rng.nextDouble() * 8;

            if (i < m.loopCount) {
                cell.type  = "loop";
                cell.color = "#00e5ff";
            } else {
                cell.type  = "if";
                cell.color = "#bf80ff";
            }
            c.cells.add(cell);
        }

        // ── Mutations (nested loops = tumors) ─────────────────
        for (int i = 0; i < Math.min(m.nestedLoopCount, 12); i++) {
            Mutation mu   = new Mutation();
            double angle  = rng.nextDouble() * 2 * Math.PI;
            double dist   = c.bodyRadius * 0.5 * rng.nextDouble();
            mu.cx         = Math.cos(angle) * dist;
            mu.cy         = Math.sin(angle) * dist;
            mu.size       = 8 + rng.nextInt(12);
            mu.color      = "#ff4060";
            mu.pulseSpeed = 0.5 + rng.nextDouble();
            c.mutations.add(mu);
        }

        // ── Traits ────────────────────────────────────────────
        if (m.methodCount > 8)      c.traits.add("Multi-functional");
        if (m.importCount > 5)      c.traits.add("Highly dependent");
        if (m.commentLines > m.codeLines / 3) c.traits.add("Well-documented");
        if (m.tryCount > 0)         c.traits.add("Error-resistant");
        if (m.nestedLoopCount > 2)  c.traits.add("⚠ Deeply nested");
        if (m.classCount > 2)       c.traits.add("Multi-cellular");
        if (m.healthScore > 80)     c.traits.add("✨ Clean DNA");
        if (c.traits.isEmpty())     c.traits.add("Simple organism");

        return c;
    }

    private static int clamp(int val, int min, int max) {
        return Math.max(min, Math.min(max, val));
    }
}
