package codedna;

import java.util.*;

/**
 * Week 8 - Enhanced Visualization.
 *
 * Turns a Creature into an animated SVG:
 *   - Body      : organic blob that morphs + pulses (speed = code complexity)
 *   - Tentacles : one per method, tapered, waving (length = method length)
 *   - Cells     : loops orbit clockwise, if-statements orbit counter-clockwise
 *   - Mutations : throbbing red tumours (nested loops)
 *   - Nucleus   : heart-beating core (class count)
 *   - Aura      : breathing health halo + slowly rotating outer ring
 *
 * All motion is done with CSS animations and SVG (SMIL) animation, so the
 * output stays a single self-contained HTML file with no libraries.
 */
public class SVGBuilder {

    private static final int W  = 900;   // SVG canvas width
    private static final int H  = 800;   // SVG canvas height
    private static final int CX = 450;   // creature centre X
    private static final int CY = 380;   // creature centre Y

    // ── Public entry point ───────────────────────────────────────
    public static String build(CreatureGenerator.Creature c) {
        Random rng = new Random(c.name.hashCode());   // same file -> same look

        StringBuilder svg = new StringBuilder();
        svg.append("<svg id='creature-svg' viewBox='0 0 ").append(W).append(' ').append(H)
           .append("' xmlns='http://www.w3.org/2000/svg'>\n");

        double k = fitScale(c);   // small creatures are enlarged, big ones still fit

        svg.append(buildDefs(c));
        svg.append(buildStyles());
        svg.append(buildStars(rng));

        // everything that belongs to the creature is scaled around its centre
        svg.append(String.format(Locale.ROOT,
                "<g id='creature' transform='translate(%d %d) scale(%.3f) translate(%d %d)'>\n",
                CX, CY, k, -CX, -CY));
        svg.append(buildAura(c));
        svg.append(buildOrbitRings(c));
        svg.append(buildTentacles(c, k));
        svg.append(buildBody(c, rng));
        svg.append(buildMutations(c));
        svg.append(buildNucleus(c));
        svg.append(buildCells(c));
        svg.append("</g>\n");

        svg.append(buildLabel(c));

        svg.append("</svg>\n");
        return svg.toString();
    }

    /** Same creature as a stand-alone .svg file (adds a dark background so it looks right on its own). */
    public static String buildStandalone(CreatureGenerator.Creature c) {
        String svg = build(c);
        int end = svg.indexOf('>') + 1;                       // end of the opening <svg ...> tag
        return "<?xml version='1.0' encoding='UTF-8'?>\n"
             + svg.substring(0, end)
             + "\n<rect width='" + W + "' height='" + H + "' fill='#070b14'/>"
             + svg.substring(end);
    }

    // ── Auto-fit: how much to zoom the creature so it fills the canvas ──
    private static double fitScale(CreatureGenerator.Creature c) {
        double reach = c.auraRadius + 14;                        // aura ring
        for (CreatureGenerator.Tentacle t : c.tentacles)
            reach = Math.max(reach, c.bodyRadius + t.length);    // tentacle tips
        for (CreatureGenerator.Cell cell : c.cells)
            reach = Math.max(reach, cell.orbitRadius + cell.radius);   // orbiting cells
        // leave ~110 units on each side for the method-name labels
        double k = 330.0 / (reach + 16);
        return Math.max(0.85, Math.min(2.2, k));
    }

    // ── Gradients + glow filters ─────────────────────────────────
    private static String buildDefs(CreatureGenerator.Creature c) {
        StringBuilder d = new StringBuilder("<defs>\n");

        // soft glow used on tentacles / nucleus
        d.append("<filter id='glow' x='-30%' y='-30%' width='160%' height='160%'>")
         .append("<feGaussianBlur stdDeviation='3' result='b'/>")
         .append("<feMerge><feMergeNode in='b'/><feMergeNode in='SourceGraphic'/></feMerge></filter>\n");

        // bigger glow used on the body
        d.append("<filter id='bodyGlow' x='-30%' y='-30%' width='160%' height='160%'>")
         .append("<feGaussianBlur stdDeviation='9' result='b'/>")
         .append("<feMerge><feMergeNode in='b'/><feMergeNode in='SourceGraphic'/></feMerge></filter>\n");

        // membrane: transparent centre, bright rim
        d.append(String.format(Locale.ROOT,
                "<radialGradient id='rim' cx='50%%' cy='50%%' r='50%%'>"
              + "<stop offset='0%%' stop-color='%s' stop-opacity='0'/>"
              + "<stop offset='65%%' stop-color='%s' stop-opacity='0.10'/>"
              + "<stop offset='100%%' stop-color='%s' stop-opacity='0.65'/></radialGradient>\n",
                c.bodyGlow, c.bodyGlow, c.bodyGlow));

        // wet highlight on the upper-left of the body
        d.append("<radialGradient id='sheen' cx='35%' cy='30%' r='55%'>")
         .append("<stop offset='0%' stop-color='#ffffff' stop-opacity='0.28'/>")
         .append("<stop offset='100%' stop-color='#ffffff' stop-opacity='0'/></radialGradient>\n");

        // nucleus core + halo
        d.append(String.format(Locale.ROOT,
                "<radialGradient id='nuc' cx='40%%' cy='38%%' r='65%%'>"
              + "<stop offset='0%%' stop-color='#ffffff'/>"
              + "<stop offset='100%%' stop-color='%s'/></radialGradient>\n", c.nucleusColor));
        d.append(String.format(Locale.ROOT,
                "<radialGradient id='nucHalo'>"
              + "<stop offset='0%%' stop-color='%s' stop-opacity='0.55'/>"
              + "<stop offset='100%%' stop-color='%s' stop-opacity='0'/></radialGradient>\n",
                c.nucleusColor, c.nucleusColor));

        // big soft aura glow behind everything
        d.append(String.format(Locale.ROOT,
                "<radialGradient id='auraGlow'>"
              + "<stop offset='55%%' stop-color='%s' stop-opacity='0'/>"
              + "<stop offset='80%%' stop-color='%s' stop-opacity='0.16'/>"
              + "<stop offset='100%%' stop-color='%s' stop-opacity='0'/></radialGradient>\n",
                c.auraColor, c.auraColor, c.auraColor));

        d.append("</defs>\n");
        return d.toString();
    }

    // ── CSS animations (inside the SVG) ──────────────────────────
    private static String buildStyles() {
        String o = CX + "px " + CY + "px";   // rotate / scale around creature centre
        return "<style>\n"
             + ".body-pulse{transform-origin:" + o + ";animation:pulse 3s ease-in-out infinite}\n"
             + ".nucleus{transform-origin:" + o + ";animation:beat 1.6s ease-in-out infinite}\n"
             + ".orbit-cw{transform-origin:" + o + ";animation:spinCW 10s linear infinite}\n"
             + ".orbit-ccw{transform-origin:" + o + ";animation:spinCCW 10s linear infinite}\n"
             + ".aura-spin{transform-origin:" + o + ";animation:spinCW 60s linear infinite}\n"
             + ".aura-breathe{animation:breathe 4s ease-in-out infinite}\n"
             + ".mutation{transform-box:fill-box;transform-origin:center;animation:throb 1s ease-in-out infinite}\n"
             + ".star{animation:twinkle 3s ease-in-out infinite}\n"
             + ".tentacle{cursor:pointer}\n"
             + ".tentacle:hover path{fill-opacity:1}\n"
             + ".tentacle:hover text{opacity:1;font-weight:bold}\n"
             + "@keyframes pulse{0%,100%{transform:scale(1)}50%{transform:scale(1.045)}}\n"
             + "@keyframes beat{0%,100%{transform:scale(1)}15%{transform:scale(1.14)}30%{transform:scale(1)}45%{transform:scale(1.08)}60%{transform:scale(1)}}\n"
             + "@keyframes spinCW{to{transform:rotate(360deg)}}\n"
             + "@keyframes spinCCW{to{transform:rotate(-360deg)}}\n"
             + "@keyframes breathe{0%,100%{opacity:calc(var(--o) * 0.55)}50%{opacity:var(--o)}}\n"
             + "@keyframes throb{0%,100%{transform:scale(0.85);opacity:0.6}50%{transform:scale(1.25);opacity:1}}\n"
             + "@keyframes twinkle{0%,100%{opacity:0.15}50%{opacity:0.85}}\n"
             + "@media (prefers-reduced-motion:reduce){*{animation:none !important}}\n"
             + "</style>\n";
    }

    // ── Background stars ─────────────────────────────────────────
    private static String buildStars(Random rng) {
        StringBuilder sb = new StringBuilder("<g id='stars' fill='#ffffff'>\n");
        for (int i = 0; i < 45; i++) {
            sb.append(String.format(Locale.ROOT,
                    "<circle class='star' cx='%.0f' cy='%.0f' r='%.1f' style='animation-duration:%.1fs;animation-delay:-%.1fs'/>\n",
                    rng.nextDouble() * W, rng.nextDouble() * H,
                    0.6 + rng.nextDouble() * 1.2,
                    2 + rng.nextDouble() * 4, rng.nextDouble() * 5));
        }
        return sb.append("</g>\n").toString();
    }

    // ── Aura: glow + breathing ring + slow rotating dashed ring ──
    private static String buildAura(CreatureGenerator.Creature c) {
        StringBuilder sb = new StringBuilder("<g id='aura'>\n");
        sb.append(String.format(Locale.ROOT,
                "<circle cx='%d' cy='%d' r='%d' fill='url(#auraGlow)'/>\n",
                CX, CY, c.auraRadius + 110));
        sb.append(String.format(Locale.ROOT,
                "<circle class='aura-breathe' style='--o:%.2f' cx='%d' cy='%d' r='%d' fill='none' stroke='%s' stroke-width='3'/>\n",
                c.auraOpacity, CX, CY, c.auraRadius, c.auraColor));
        sb.append(String.format(Locale.ROOT,
                "<circle class='aura-spin' cx='%d' cy='%d' r='%d' fill='none' stroke='%s' stroke-width='1.5' stroke-dasharray='10 14' opacity='0.35'/>\n",
                CX, CY, c.auraRadius + 14, c.auraColor));
        return sb.append("</g>\n").toString();
    }

    // ── Faint orbit tracks under the cells ───────────────────────
    private static String buildOrbitRings(CreatureGenerator.Creature c) {
        TreeSet<Long> radii = new TreeSet<>();
        for (CreatureGenerator.Cell cell : c.cells) radii.add(Math.round(cell.orbitRadius));
        StringBuilder sb = new StringBuilder("<g id='orbit-tracks' fill='none' stroke='#ffffff' stroke-opacity='0.07' stroke-dasharray='2 6'>\n");
        for (long r : radii) {
            sb.append(String.format(Locale.ROOT, "<circle cx='%d' cy='%d' r='%d'/>\n", CX, CY, r));
        }
        return sb.append("</g>\n").toString();
    }

    // ── Tentacles (methods) ──────────────────────────────────────
    private static String buildTentacles(CreatureGenerator.Creature c, double k) {
        StringBuilder sb = new StringBuilder("<g id='tentacles' filter='url(#glow)'>\n");

        for (CreatureGenerator.Tentacle t : c.tentacles) {
            double a  = t.angle - Math.PI / 2;            // first tentacle points up
            double dx = Math.cos(a), dy = Math.sin(a);    // outward direction
            double px = -dy,         py = dx;             // sideways direction

            double bx  = CX + dx * c.bodyRadius * 0.85;   // base hides inside body
            double by  = CY + dy * c.bodyRadius * 0.85;
            double len = t.length + c.bodyRadius * 0.15;  // so the tip reaches bodyRadius + length
            double amp = 10 + t.length * 0.12;            // how far it swings sideways

            double hw0 = t.thickness / 2.0 + 1.5;         // half-width at base -> tapers to a point
            double hw1 = hw0 * 0.70;
            double hw2 = hw0 * 0.40;

            String dPos = tentaclePath(bx, by, dx, dy, px, py, len, amp, hw0, hw1, hw2,  1);
            String dNeg = tentaclePath(bx, by, dx, dy, px, py, len, amp, hw0, hw1, hw2, -1);

            double dur   = 8.0 / t.waveSpeed;             // faster waveSpeed -> shorter cycle
            double begin = -(t.angle * 1.7 % dur);        // stagger so they don't wave in sync

            double tipDist = len;
            double tipXp = bx + dx * tipDist + px * amp * 0.5,  tipYp = by + dy * tipDist + py * amp * 0.5;
            double tipXn = bx + dx * tipDist - px * amp * 0.5,  tipYn = by + dy * tipDist - py * amp * 0.5;

            String timing = String.format(Locale.ROOT,
                    "dur='%.2fs' begin='%.2fs' repeatCount='indefinite' calcMode='spline' keyTimes='0;0.5;1' "
                  + "keySplines='0.45 0 0.55 1;0.45 0 0.55 1'", dur, begin);

            sb.append("<g class='tentacle'>\n");
            sb.append("<title>").append(esc(t.methodName)).append("()  -  ")
              .append(t.methodLines).append(" lines</title>\n");

            // tapered body of the tentacle
            sb.append(String.format(Locale.ROOT,
                    "<path d='%s' fill='%s' fill-opacity='0.88' stroke='%s' stroke-opacity='0.5' stroke-width='0.6'>"
                  + "<animate attributeName='d' values='%s;%s;%s' %s/></path>\n",
                    dPos, t.color, t.color, dPos, dNeg, dPos, timing));

            // glowing tip that follows the wave
            double tipR = hw0 * 0.75 + 1.5;
            sb.append(String.format(Locale.ROOT,
                    "<circle cx='%.1f' cy='%.1f' r='%.1f' fill='%s' stroke='#ffffff' stroke-opacity='0.6' stroke-width='0.8'>"
                  + "<animate attributeName='cx' values='%.1f;%.1f;%.1f' %s/>"
                  + "<animate attributeName='cy' values='%.1f;%.1f;%.1f' %s/></circle>\n",
                    tipXp, tipYp, tipR, t.color,
                    tipXp, tipXn, tipXp, timing,
                    tipYp, tipYn, tipYp, timing));

            // method name at the end of the tentacle
            double lx = bx + dx * (tipDist + 24);
            double ly = by + dy * (tipDist + 24);
            String anchor = dx > 0.3 ? "start" : (dx < -0.3 ? "end" : "middle");
            double ty = ly + (dy > 0.5 ? 10 : (dy < -0.5 ? -4 : 4));
            sb.append(String.format(Locale.ROOT,
                    "<text x='%.1f' y='%.1f' text-anchor='%s' font-family='monospace' font-size='%.1f' fill='#9fb3c8' opacity='0.85'>%s()</text>\n",
                    lx, ty, anchor, 12.5 / k, esc(shorten(t.methodName, 14))));

            sb.append("</g>\n");
        }
        return sb.append("</g>\n").toString();
    }

    /** One frame of the wave: a tapered closed shape whose middle bends by 'sway' (+1 / -1). */
    private static String tentaclePath(double bx, double by, double dx, double dy,
                                       double px, double py, double len, double amp,
                                       double hw0, double hw1, double hw2, int sway) {
        // centre-line control points make an S-curve
        double c1x = bx + dx * len * 0.33 + px * amp * sway;
        double c1y = by + dy * len * 0.33 + py * amp * sway;
        double c2x = bx + dx * len * 0.66 - px * amp * sway * 0.8;
        double c2y = by + dy * len * 0.66 - py * amp * sway * 0.8;
        double tx  = bx + dx * len        + px * amp * sway * 0.5;
        double ty  = by + dy * len        + py * amp * sway * 0.5;

        return String.format(Locale.ROOT,
                "M%.1f %.1f C%.1f %.1f %.1f %.1f %.1f %.1f C%.1f %.1f %.1f %.1f %.1f %.1f Z",
                bx + px * hw0, by + py * hw0,                       // left edge of base
                c1x + px * hw1, c1y + py * hw1,
                c2x + px * hw2, c2y + py * hw2,
                tx, ty,                                             // tip
                c2x - px * hw2, c2y - py * hw2,
                c1x - px * hw1, c1y - py * hw1,
                bx - px * hw0, by - py * hw0);                      // right edge of base
    }

    // ── Body: organic blob that morphs and pulses ────────────────
    private static String buildBody(CreatureGenerator.Creature c, Random rng) {
        int n = 10;
        String shapeA = blobPath(c.bodyRadius, n, rng);
        String shapeB = blobPath(c.bodyRadius, n, rng);
        double dur = c.pulseSpeed * 2;

        String morph = String.format(Locale.ROOT,
                "<animate attributeName='d' values='%s;%s;%s' dur='%.2fs' repeatCount='indefinite' "
              + "calcMode='spline' keyTimes='0;0.5;1' keySplines='0.45 0 0.55 1;0.45 0 0.55 1'/>",
                shapeA, shapeB, shapeA, dur);

        StringBuilder sb = new StringBuilder();
        sb.append(String.format(Locale.ROOT,
                "<g id='body' class='body-pulse' style='animation-duration:%.2fs'>\n", c.pulseSpeed));

        // 1) coloured, glowing body
        sb.append(String.format(Locale.ROOT,
                "<path d='%s' fill='%s' stroke='%s' stroke-width='1.5' filter='url(#bodyGlow)'>%s</path>\n",
                shapeA, c.bodyColor, c.bodyGlow, morph));
        // 2) bright membrane rim
        sb.append(String.format(Locale.ROOT,
                "<path d='%s' fill='url(#rim)'>%s</path>\n", shapeA, morph));
        // 3) wet sheen
        sb.append(String.format(Locale.ROOT,
                "<path d='%s' fill='url(#sheen)'>%s</path>\n", shapeA, morph));

        // 4) small organelles floating inside
        double lo = c.nucleusRadius + 12, hi = c.bodyRadius * 0.72;
        if (hi > lo) {
            int count = 6 + c.bodyRadius / 20;
            for (int i = 0; i < count; i++) {
                double ang  = rng.nextDouble() * Math.PI * 2;
                double dist = lo + rng.nextDouble() * (hi - lo);
                sb.append(String.format(Locale.ROOT,
                        "<circle cx='%.1f' cy='%.1f' r='%.1f' fill='#ffffff' opacity='%.2f'/>\n",
                        CX + Math.cos(ang) * dist, CY + Math.sin(ang) * dist,
                        2.5 + rng.nextDouble() * 5.5, 0.07 + rng.nextDouble() * 0.10));
            }
        }
        return sb.append("</g>\n").toString();
    }

    /** Smooth closed blob (Catmull-Rom -> cubic Bezier) with slightly uneven radius. */
    private static String blobPath(int radius, int n, Random rng) {
        double[] x = new double[n], y = new double[n];
        for (int i = 0; i < n; i++) {
            double ang = 2 * Math.PI * i / n;
            double r   = radius * (1 + (rng.nextDouble() - 0.5) * 0.14);
            x[i] = CX + Math.cos(ang) * r;
            y[i] = CY + Math.sin(ang) * r;
        }
        StringBuilder d = new StringBuilder(String.format(Locale.ROOT, "M%.1f %.1f", x[0], y[0]));
        for (int i = 0; i < n; i++) {
            int p0 = (i - 1 + n) % n, p1 = i, p2 = (i + 1) % n, p3 = (i + 2) % n;
            d.append(String.format(Locale.ROOT, " C%.1f %.1f %.1f %.1f %.1f %.1f",
                    x[p1] + (x[p2] - x[p0]) / 6, y[p1] + (y[p2] - y[p0]) / 6,
                    x[p2] - (x[p3] - x[p1]) / 6, y[p2] - (y[p3] - y[p1]) / 6,
                    x[p2], y[p2]));
        }
        return d.append(" Z").toString();
    }

    // ── Mutations (nested loops): throbbing red tumours ──────────
    private static String buildMutations(CreatureGenerator.Creature c) {
        StringBuilder sb = new StringBuilder("<g id='mutations'>\n");
        for (CreatureGenerator.Mutation mu : c.mutations) {
            sb.append(String.format(Locale.ROOT,
                    "<g class='mutation' style='animation-duration:%.2fs'><title>Nested loop (mutation)</title>"
                  + "<circle cx='%.1f' cy='%.1f' r='%d' fill='%s' opacity='0.85'/>"
                  + "<circle cx='%.1f' cy='%.1f' r='%d' fill='none' stroke='#ffffff' stroke-width='1.2' stroke-dasharray='3 3' opacity='0.75'/></g>\n",
                    mu.pulseSpeed,
                    CX + mu.cx, CY + mu.cy, mu.size, mu.color,
                    CX + mu.cx, CY + mu.cy, mu.size + 5));
        }
        return sb.append("</g>\n").toString();
    }

    // ── Nucleus (classes): glowing, heart-beating core ───────────
    private static String buildNucleus(CreatureGenerator.Creature c) {
        return String.format(Locale.ROOT,
                "<g id='nucleus' class='nucleus'><title>Nucleus (classes)</title>"
              + "<circle cx='%d' cy='%d' r='%.1f' fill='url(#nucHalo)'/>"
              + "<circle cx='%d' cy='%d' r='%d' fill='url(#nuc)' filter='url(#glow)'/>"
              + "<circle cx='%.1f' cy='%.1f' r='%.1f' fill='#000000' opacity='0.22'/></g>\n",
                CX, CY, c.nucleusRadius * 1.9,
                CX, CY, c.nucleusRadius,
                CX + c.nucleusRadius * 0.15, CY + c.nucleusRadius * 0.15, c.nucleusRadius * 0.35);
    }

    // ── Cells (loops cw, ifs ccw) orbiting the body ──────────────
    private static String buildCells(CreatureGenerator.Creature c) {
        StringBuilder sb = new StringBuilder("<g id='cells'>\n");
        for (CreatureGenerator.Cell cell : c.cells) {
            boolean loop = "loop".equals(cell.type);
            double dur = cell.orbitSpeed * 2;   // seconds per full orbit
            sb.append(String.format(Locale.ROOT,
                    "<g class='%s' style='animation-duration:%.1fs'><title>%s</title>"
                  + "<circle cx='%.1f' cy='%.1f' r='%.1f' fill='%s' opacity='0.18'/>"
                  + "<circle cx='%.1f' cy='%.1f' r='%d' fill='%s' opacity='0.92' stroke='#ffffff' stroke-opacity='0.5' stroke-width='0.8'/></g>\n",
                    loop ? "orbit-cw" : "orbit-ccw", dur,
                    loop ? "Loop cell" : "Conditional (if) cell",
                    CX + cell.cx, CY + cell.cy, cell.radius * 1.9, cell.color,
                    CX + cell.cx, CY + cell.cy, cell.radius, cell.color));
        }
        return sb.append("</g>\n").toString();
    }

    // ── Name + personality label at the bottom ───────────────────
    private static String buildLabel(CreatureGenerator.Creature c) {
        return String.format(Locale.ROOT,
                "<text x='%d' y='%d' text-anchor='middle' font-family='monospace' font-size='22' font-weight='bold' letter-spacing='2' fill='%s'>%s</text>\n"
              + "<text x='%d' y='%d' text-anchor='middle' font-family='monospace' font-size='13' letter-spacing='4' fill='#8fa3ba'>%s</text>\n",
                CX, H - 34, c.bodyGlow, esc(c.name),
                CX, H - 12, esc(c.personality == null ? "" : c.personality.toUpperCase()));
    }

    // ── Helpers ──────────────────────────────────────────────────
    private static String shorten(String s, int max) {
        return s.length() <= max ? s : s.substring(0, max - 1) + "~";
    }

    static String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("'", "&#39;");
    }
}
