package codedna;

import java.io.IOException;
import java.io.StringReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.xml.parsers.DocumentBuilderFactory;
import org.xml.sax.InputSource;

/**
 * CodeDNA self-test (no libraries needed).
 *
 * Checks the parser on small inline programs, the creature mapping on the
 * files in sample/, the SVG / HTML output, and the whole pipeline.
 *
 * Run from the project root (IntelliJ: right-click SelfTest -> Run):
 *     java -cp "out/production/CodeDNA Engine" codedna.SelfTest
 * Exit code is 0 when every check passes, 1 otherwise.
 */
public class SelfTest {

    private static int passed = 0, failed = 0;

    public static void main(String[] args) throws Exception {
        String sampleDir = args.length > 0 ? args[0] : "sample";
        Path tmp = Files.createTempDirectory("codedna_selftest");

        System.out.println();
        System.out.println("  CodeDNA self-test");
        System.out.println("  " + "=".repeat(60));

        parserAccuracy(tmp);
        sampleFiles(sampleDir);
        outputAndPipeline(sampleDir, tmp);
        errorHandling(tmp);

        System.out.println("\n  " + "=".repeat(60));
        System.out.println("  " + passed + " passed, " + failed + " failed");
        System.out.println(failed == 0 ? "  ALL TESTS PASSED" : "  SOME TESTS FAILED");
        System.out.println();
        if (failed > 0) System.exit(1);
    }

    // ── 1. Parser accuracy on tiny inline programs ───────────────
    private static void parserAccuracy(Path tmp) throws IOException {
        section("Parser accuracy");

        ASTParser.CodeMetrics m = parseText(tmp, "Nested",
                "public class Nested {\n"
              + "    void a() {\n"
              + "        for (int i = 0; i < 3; i++) {\n"
              + "            for (int j = 0; j < 3; j++) {\n"
              + "                if (i == j) { }\n"
              + "            }\n"
              + "        }\n"
              + "    }\n"
              + "}\n");
        check("nested loop is detected",            m.loopCount == 2 && m.nestedLoopCount == 1);
        check("if inside loop is counted once",     m.ifCount == 1);

        m = parseText(tmp, "Siblings",
                "public class Siblings {\n"
              + "    void a() {\n"
              + "        for (int i = 0; i < 3; i++) { }\n"
              + "        for (int j = 0; j < 3; j++) { }\n"
              + "        while (false) { }\n"
              + "    }\n"
              + "}\n");
        check("loops one after another are NOT nested", m.loopCount == 3 && m.nestedLoopCount == 0);

        m = parseText(tmp, "Triple",
                "public class Triple {\n"
              + "    void a() {\n"
              + "        for (int i = 0; i < 3; i++) {\n"
              + "            for (int j = 0; j < 3; j++) {\n"
              + "                for (int k = 0; k < 3; k++) { }\n"
              + "            }\n"
              + "        }\n"
              + "    }\n"
              + "}\n");
        check("triple nesting gives 2 nested loops", m.loopCount == 3 && m.nestedLoopCount == 2);

        m = parseText(tmp, "DoWhile",
                "public class DoWhile {\n"
              + "    void a() {\n"
              + "        int i = 0;\n"
              + "        do {\n"
              + "            i++;\n"
              + "        } while (i < 3);\n"
              + "    }\n"
              + "}\n");
        check("do-while counts as ONE loop", m.loopCount == 1);

        m = parseText(tmp, "Strings",
                "public class Strings {\n"
              + "    // for (;;) while (x) if (y) {\n"
              + "    /* for (int i = 0; i < 3; i++) { */\n"
              + "    void a() {\n"
              + "        System.out.println(\"for (int i) while (x) if (y) { try {\");\n"
              + "    }\n"
              + "}\n");
        check("keywords in comments / strings are ignored", m.loopCount == 0 && m.ifCount == 0 && m.tryCount == 0);
        check("braces inside strings do not confuse depth",  m.methodCount == 1
                && m.methodLineCounts.get("a") == 3);

        m = parseText(tmp, "Methods",
                "public class Methods {\n"
              + "    private int total = compute(3);\n"
              + "    public Methods() {\n"
              + "    }\n"
              + "    public int compute(int x) {\n"
              + "        int y = helper(x);\n"
              + "        return y;\n"
              + "    }\n"
              + "    private int helper(int x) { return x * 2; }\n"
              + "    interface Shape {\n"
              + "        double area();\n"
              + "    }\n"
              + "}\n");
        check("methods, constructor and interface method found",
                m.methodNames.equals(Arrays.asList("Methods", "compute", "helper", "area")));
        check("field initialiser / calls are not methods", !m.methodNames.contains("total"));
        check("method length = signature to closing brace", m.methodLineCounts.get("compute") == 4);
        check("class + interface counted",                  m.classCount == 2);

        m = parseText(tmp, "Overload",
                "public class Overload {\n"
              + "    int add(int a, int b) { return a + b; }\n"
              + "    int add(int a, int b, int c) { return a + b + c; }\n"
              + "}\n");
        check("overloaded methods get separate tentacles", m.methodNames.equals(Arrays.asList("add", "add#2")));

        m = parseText(tmp, "Comments",
                "// one\n"
              + "/* two\n"
              + "   three */\n"
              + "\n"
              + "/** four */\n"
              + "public class Comments {\n"
              + "}\n");
        check("comment / code / blank lines are classified",
                m.commentLines == 4 && m.codeLines == 2 && m.blankLines == 1);
    }

    // ── 2. Sample files -> creature mapping ──────────────────────
    private static void sampleFiles(String dir) throws IOException {
        section("Sample files -> creatures");

        CreatureGenerator.Creature c;
        ASTParser.CodeMetrics m;

        m = ASTParser.parse(dir + "/FirstDemo.java");
        c = CreatureGenerator.generate(m);
        check("FirstDemo: 3 methods, 2 loops, 2 ifs, no nesting",
                m.methodCount == 3 && m.loopCount == 2 && m.ifCount == 2 && m.nestedLoopCount == 0);
        check("FirstDemo: 3 tentacles, 4 cells, 0 tumours, 'Warrior'",
                c.tentacles.size() == 3 && c.cells.size() == 4 && c.mutations.isEmpty()
                && "Warrior".equals(c.personality));

        m = ASTParser.parse(dir + "/CleanCode.java");
        c = CreatureGenerator.generate(m);
        check("CleanCode: healthy blue 'Elegant' creature, no tumours",
                "Elegant".equals(c.personality) && c.mutations.isEmpty() && c.healthScore >= 75);

        m = ASTParser.parse(dir + "/MessyCode.java");
        c = CreatureGenerator.generate(m);
        check("MessyCode: nested loops become tumours",
                m.nestedLoopCount >= 3 && c.mutations.size() == m.nestedLoopCount);
        check("MessyCode: unhealthy red 'Chaotic' creature", "Chaotic".equals(c.personality));
        boolean hasRed = false;
        for (CreatureGenerator.Tentacle t : c.tentacles) if (t.methodLines > 40) hasRed = "#ff6b6b".equals(t.color);
        check("MessyCode: a >40 line method has a red tentacle", hasRed);

        m = ASTParser.parse(dir + "/BigService.java");
        c = CreatureGenerator.generate(m);
        check("BigService: 16 tentacles maximum, even with more methods",
                m.methodCount > 16 && c.tentacles.size() == 16);
        check("BigService: 'Warrior' (not Elegant, not Chaotic)", "Warrior".equals(c.personality));

        m = ASTParser.parse(dir + "/MultiClass.java");
        c = CreatureGenerator.generate(m);
        check("MultiClass: many classes give a bigger, yellow nucleus",
                m.classCount > 3 && "#ffe066".equals(c.nucleusColor));

        CreatureGenerator.Creature a = CreatureGenerator.generate(ASTParser.parse(dir + "/MessyCode.java"));
        CreatureGenerator.Creature b = CreatureGenerator.generate(ASTParser.parse(dir + "/MessyCode.java"));
        check("same file always gives the same creature (SVG identical)",
                SVGBuilder.build(a).equals(SVGBuilder.build(b)));
    }

    // ── 3. Output files + full pipeline ──────────────────────────
    private static void outputAndPipeline(String dir, Path tmp) throws Exception {
        section("Output and full pipeline");

        List<ASTParser.CodeMetrics> ms = new ArrayList<>();
        List<CreatureGenerator.Creature> cs = new ArrayList<>();
        String out = tmp.resolve("output").toString();

        for (String name : new String[]{"FirstDemo", "CleanCode", "MessyCode", "BigService", "MultiClass"}) {
            Main.Result r = Main.process(dir + "/" + name + ".java", out, true);
            ms.add(r.metrics);
            cs.add(r.creature);

            String svg  = SVGBuilder.build(r.creature);
            String html = Files.readString(Paths.get(r.htmlPath));
            check(name + ": HTML + SVG files written",
                    Files.size(Paths.get(r.htmlPath)) > 1000 && Files.size(Paths.get(r.svgPath)) > 1000);
            check(name + ": SVG is well-formed XML with no NaN/Infinity", wellFormed(svg) && !svg.contains("NaN")
                    && !svg.contains("Infinity"));
            check(name + ": page contains the file name and the stats panel",
                    html.contains(name + ".java") && html.contains("Code anatomy"));
            check(name + ": standalone SVG is well-formed",
                    wellFormed(Files.readString(Paths.get(r.svgPath)).replaceFirst("^<\\?xml[^>]*\\?>\\s*", "")));
        }

        String gallery = HTMLExporter.exportGallery(ms, cs, out + "/index.html");
        String g = Files.readString(Paths.get(gallery));
        boolean all = true;
        for (ASTParser.CodeMetrics m : ms) all &= g.contains(HTMLExporter.baseName(m) + "_DNA.html");
        check("gallery links to every creature", all);
    }

    // ── 4. Bad input ─────────────────────────────────────────────
    private static void errorHandling(Path tmp) throws Exception {
        section("Error handling");

        boolean threw = false;
        try { ASTParser.parse(tmp.resolve("DoesNotExist.java").toString()); }
        catch (IOException e) { threw = true; }
        check("missing file gives a clear IOException", threw);

        Path empty = tmp.resolve("Empty.java");
        Files.writeString(empty, "");
        Main.Result r = Main.process(empty.toString(), tmp.resolve("output").toString(), false);
        check("empty file still produces a valid organism",
                r.creature.tentacles.isEmpty() && wellFormed(SVGBuilder.build(r.creature)));

        Path odd = tmp.resolve("Odd.java");
        Files.writeString(odd, "class Odd { void a( { for ( } ) ]]]] \n \"unterminated\n");
        r = Main.process(odd.toString(), tmp.resolve("output").toString(), false);
        check("broken / unbalanced code does not crash the tool", wellFormed(SVGBuilder.build(r.creature)));
    }

    // ── helpers ──────────────────────────────────────────────────
    private static ASTParser.CodeMetrics parseText(Path tmp, String className, String code) throws IOException {
        Path f = tmp.resolve(className + ".java");
        Files.writeString(f, code);
        return ASTParser.parse(f.toString());
    }

    private static boolean wellFormed(String xml) {
        try {
            DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new InputSource(new StringReader(xml)));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private static void section(String title) {
        System.out.println("\n  " + title);
        System.out.println("  " + "-".repeat(60));
    }

    private static void check(String name, boolean ok) {
        if (ok) passed++; else failed++;
        System.out.println("  [" + (ok ? "PASS" : "FAIL") + "] " + name);
    }
}
