package codedna;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * CodeDNA entry point - runs the whole pipeline:
 *
 *   ASTParser  ->  CreatureGenerator  ->  SVGBuilder  ->  HTMLExporter
 *
 * Usage
 *   (no arguments)              asks for a .java file or a folder
 *   Main sample/FirstDemo.java  one file
 *   Main sample                 every .java file in that folder (+ gallery page)
 *   Main a.java b.java          several files (+ gallery page)
 *   Main ... --no-open          do not open the browser automatically
 */
public class Main {

    static final String OUTPUT_DIR    = "output";
    static final String DEFAULT_INPUT = "sample/FirstDemo.java";

    /** Everything produced for one input file. */
    public static class Result {
        public final ASTParser.CodeMetrics metrics;
        public final CreatureGenerator.Creature creature;
        public final String htmlPath;
        public final String svgPath;
        public final long millis;

        Result(ASTParser.CodeMetrics m, CreatureGenerator.Creature c, String html, String svg, long millis) {
            this.metrics = m; this.creature = c; this.htmlPath = html; this.svgPath = svg; this.millis = millis;
        }
    }

    // ── Pipeline for ONE file (no printing, so it can also be tested) ─────
    public static Result process(String inputPath, String outDir, boolean galleryLink) throws IOException {
        long t0 = System.nanoTime();

        ASTParser.CodeMetrics metrics       = ASTParser.parse(inputPath);          // Step 1
        CreatureGenerator.Creature creature = CreatureGenerator.generate(metrics); // Step 2
        String svg                          = SVGBuilder.build(creature);          // Step 3

        Files.createDirectories(Paths.get(outDir));
        String base     = HTMLExporter.baseName(metrics);
        String htmlPath = outDir + "/" + base + "_DNA.html";
        String svgPath  = outDir + "/" + base + "_DNA.svg";

        HTMLExporter.export(metrics, creature, svg, htmlPath, galleryLink);        // Step 4
        Files.writeString(Paths.get(svgPath), SVGBuilder.buildStandalone(creature));

        return new Result(metrics, creature, htmlPath, svgPath, (System.nanoTime() - t0) / 1_000_000);
    }

    // ── Program ───────────────────────────────────────────────────────────
    public static void main(String[] args) {

        printBanner();

        boolean open = true;
        List<String> inputs = new ArrayList<>();
        for (String a : args) {
            if (a.equals("--no-open")) open = false;
            else inputs.add(a);
        }

        if (inputs.isEmpty()) {
            Scanner sc = new Scanner(System.in);
            System.out.println("\n  Enter the path to a .java file (or a folder of .java files):");
            System.out.print("  > ");
            String line = sc.hasNextLine() ? sc.nextLine().trim() : "";
            line = line.replaceAll("^\"|\"$", "");            // allow pasted "quoted" paths
            if (line.isEmpty()) {
                line = DEFAULT_INPUT;
                System.out.println("  Using default: " + line);
            }
            inputs.add(line);
        }

        List<File> files = collectFiles(inputs);
        if (files.isEmpty()) {
            System.out.println("\n  ❌ No .java files to process.");
            System.exit(1);
            return;
        }

        boolean batch = files.size() > 1;
        List<ASTParser.CodeMetrics> metricsList = new ArrayList<>();
        List<CreatureGenerator.Creature> creatureList = new ArrayList<>();
        int failures = 0;
        Result last = null;

        for (File f : files) {
            try {
                if (batch) {
                    Result r = process(f.getPath(), OUTPUT_DIR, true);
                    printRow(r);
                    metricsList.add(r.metrics);
                    creatureList.add(r.creature);
                    last = r;
                } else {
                    last = runSingle(f);
                }
            } catch (Exception e) {
                failures++;
                System.out.println("  ❌ " + f.getName() + " — " + e.getClass().getSimpleName()
                        + (e.getMessage() != null ? ": " + e.getMessage() : ""));
            }
        }

        // ── Finish ─────────────────────────────────────────────
        String toOpen = null;
        if (batch && !metricsList.isEmpty()) {
            try {
                String gallery = HTMLExporter.exportGallery(metricsList, creatureList, OUTPUT_DIR + "/index.html");
                System.out.println("\n  🧬 " + metricsList.size() + " organisms saved in: " + new File(OUTPUT_DIR).getAbsolutePath());
                System.out.println("  Gallery page: " + new File(gallery).getAbsolutePath());
                toOpen = gallery;
            } catch (IOException e) {
                System.out.println("  ❌ Could not write gallery: " + e.getMessage());
                failures++;
            }
        } else if (last != null) {
            System.out.println("\n  🧬 Organism saved to: " + new File(last.htmlPath).getAbsolutePath());
            toOpen = last.htmlPath;
        }

        if (failures > 0) System.out.println("\n  " + failures + " file(s) could not be processed.");
        if (toOpen != null && open) openInBrowser(toOpen);
        else if (toOpen != null)   System.out.println("  Open that .html file in your browser to see it.");

        if (failures > 0) System.exit(1);
    }

    // ── One file, full console report ─────────────────────────────────────
    private static Result runSingle(File f) throws IOException {
        System.out.println("\n  🔬 Scanning DNA of: " + f.getName());

        System.out.print("  ▸ Parsing AST...");
        ASTParser.CodeMetrics metrics = ASTParser.parse(f.getPath());
        System.out.println(" ✔");

        System.out.println();
        System.out.println("  ===== CodeDNA Parser Results =====");
        System.out.println("  File            : " + metrics.fileName);
        System.out.println("  Total Lines     : " + metrics.totalLines);
        System.out.println("  Code Lines      : " + metrics.codeLines);
        System.out.println("  Comment Lines   : " + metrics.commentLines);
        System.out.println("  Blank Lines     : " + metrics.blankLines);
        System.out.println("  Classes         : " + metrics.classCount + " " + metrics.classNames);
        System.out.println("  Methods         : " + metrics.methodCount + " " + metrics.methodNames);
        System.out.println("  Loops           : " + metrics.loopCount);
        System.out.println("  Nested Loops    : " + metrics.nestedLoopCount);
        System.out.println("  If Statements   : " + metrics.ifCount);
        System.out.println("  Try/Catch       : " + metrics.tryCount);
        System.out.println("  Imports         : " + metrics.importCount);
        System.out.println("  Complexity Score: " + metrics.complexityScore + "/100");
        System.out.println("  Health Score    : " + metrics.healthScore + "/100");
        System.out.println("  Top Keywords    : " + metrics.keywords);
        System.out.println("  ===================================");

        System.out.print("\n  ▸ Generating organism...");
        CreatureGenerator.Creature creature = CreatureGenerator.generate(metrics);
        System.out.println(" ✔  [" + creature.personality + "]");
        System.out.println();
        System.out.println(creature);

        System.out.print("  ▸ Rendering SVG and exporting HTML...");
        Result r = process(f.getPath(), OUTPUT_DIR, false);
        System.out.println(" ✔  (" + r.millis + " ms)");
        System.out.println("  SVG file: " + new File(r.svgPath).getAbsolutePath());
        return r;
    }

    // ── One line per file when several are processed ──────────────────────
    private static int rowNo = 0;
    private static void printRow(Result r) {
        if (rowNo++ == 0) {
            System.out.println();
            System.out.printf("  %-22s %-9s %7s %6s %6s %4s %7s%n",
                    "File", "Type", "Methods", "Loops", "Nested", "Ifs", "Health");
            System.out.println("  " + "-".repeat(70));
        }
        System.out.printf("  %-22s %-9s %7d %6d %6d %4d %7d%n",
                cut(r.metrics.fileName, 22), r.creature.personality, r.metrics.methodCount,
                r.metrics.loopCount, r.metrics.nestedLoopCount, r.metrics.ifCount, r.creature.healthScore);
    }

    private static String cut(String s, int n) { return s.length() <= n ? s : s.substring(0, n - 1) + "~"; }

    // ── Turn the user's paths into a list of .java files ──────────────────
    private static List<File> collectFiles(List<String> inputs) {
        Set<File> found = new LinkedHashSet<>();
        for (String in : inputs) {
            File f = new File(in);
            if (f.isDirectory()) {
                try (Stream<Path> s = Files.list(f.toPath())) {
                    List<File> list = s.filter(p -> p.toString().endsWith(".java"))
                                       .sorted()
                                       .map(Path::toFile)
                                       .collect(Collectors.toList());
                    if (list.isEmpty()) System.out.println("\n  ⚠ No .java files in folder: " + in);
                    found.addAll(list);
                } catch (IOException e) {
                    System.out.println("\n  ❌ Cannot read folder: " + in);
                }
            } else if (!f.exists()) {
                System.out.println("\n  ❌ File not found: " + in);
            } else if (!f.getName().endsWith(".java")) {
                System.out.println("\n  ⚠ Skipped (not a .java file): " + in);
            } else {
                found.add(f);
            }
        }
        return new ArrayList<>(found);
    }

    // ── Open the result in the default browser ────────────────────────────
    private static void openInBrowser(String path) {
        File file = new File(path).getAbsoluteFile();
        try {
            if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
                Desktop.getDesktop().browse(file.toURI());
                System.out.println("  Opened in your browser.");
                return;
            }
        } catch (Exception ignored) { /* fall through to the manual message */ }
        System.out.println("  Open this file in your browser: " + file);
    }

    private static void printBanner() {
        System.out.println();
        System.out.println("  ╔══════════════════════════════════════════════╗");
        System.out.println("  ║   ██████╗ ██████╗ ██████╗ ███████╗          ║");
        System.out.println("  ║  ██╔════╝██╔═══██╗██╔══██╗██╔════╝          ║");
        System.out.println("  ║  ██║     ██║   ██║██║  ██║█████╗            ║");
        System.out.println("  ║  ██║     ██║   ██║██║  ██║██╔══╝            ║");
        System.out.println("  ║  ╚██████╗╚██████╔╝██████╔╝███████╗          ║");
        System.out.println("  ║   ╚═════╝ ╚═════╝ ╚═════╝ ╚══════╝         ║");
        System.out.println("  ║         DNA  ──  Biomorphic Code Visualizer ║");
        System.out.println("  ╚══════════════════════════════════════════════╝");
        System.out.println("  Pure Java · Zero external libraries · JDK 17+  ");
        System.out.println();
    }
}
