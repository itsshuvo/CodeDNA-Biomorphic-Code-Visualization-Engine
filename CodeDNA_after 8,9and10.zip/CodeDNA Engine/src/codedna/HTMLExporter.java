package codedna;

import java.io.*;
import java.nio.file.*;
import java.util.Locale;

/**
 * Week 8 - wraps the animated SVG in a dark sci-fi page with a
 * stats panel, health / complexity bars, method list and legend.
 */
public class HTMLExporter {

    /** File-name stem used for all outputs of one input file (FirstDemo.java -> FirstDemo). */
    public static String baseName(ASTParser.CodeMetrics m) {
        return m.fileName.endsWith(".java") ? m.fileName.substring(0, m.fileName.length() - 5) : m.fileName;
    }

    public static String export(
            ASTParser.CodeMetrics metrics,
            CreatureGenerator.Creature creature,
            String svgContent,
            String outputPath) throws IOException {
        return export(metrics, creature, svgContent, outputPath, false);
    }

    /** withGalleryLink = true adds a "back to all creatures" link (used when index.html exists). */
    public static String export(
            ASTParser.CodeMetrics metrics,
            CreatureGenerator.Creature creature,
            String svgContent,
            String outputPath,
            boolean withGalleryLink) throws IOException {

        String html = buildHTML(metrics, creature, svgContent, withGalleryLink);
        Files.writeString(Paths.get(outputPath), html);
        return outputPath;
    }

    /** Gallery page listing every creature that was generated in one run. */
    public static String exportGallery(
            java.util.List<ASTParser.CodeMetrics> metrics,
            java.util.List<CreatureGenerator.Creature> creatures,
            String outputPath) throws IOException {

        StringBuilder h = new StringBuilder();
        h.append("<!DOCTYPE html>\n<html lang='en'>\n<head>\n<meta charset='UTF-8'>\n");
        h.append("<meta name='viewport' content='width=device-width, initial-scale=1'>\n");
        h.append("<title>CodeDNA — Gallery</title>\n<style>\n");
        h.append("*{box-sizing:border-box}\n");
        h.append("body{margin:0;min-height:100vh;color:#d7e2f0;font-family:'Consolas','Courier New',monospace;"
               + "background:radial-gradient(ellipse at 40% 20%,#111c36 0%,#070b14 70%)}\n");
        h.append("header{text-align:center;padding:24px 16px 6px}\n");
        h.append("h1{margin:0;font-size:30px;letter-spacing:8px}h1 span{color:#00ff9f;text-shadow:0 0 14px #00ff9f}\n");
        h.append(".sub{color:#7f93ad;margin-top:6px;font-size:14px}\n");
        h.append(".grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:18px;max-width:1300px;margin:0 auto;padding:18px 20px 30px}\n");
        h.append(".card{display:block;text-decoration:none;color:inherit;background:rgba(15,22,38,0.85);border:1px solid #1e2a44;border-radius:14px;overflow:hidden;transition:transform .15s,border-color .15s}\n");
        h.append(".card:hover{transform:translateY(-4px);border-color:var(--c)}\n");
        h.append(".card img{display:block;width:100%;height:auto;background:#070b14}\n");
        h.append(".info{padding:12px 14px 14px}\n");
        h.append(".info h3{margin:0 0 4px;font-size:16px;color:var(--c)}\n");
        h.append(".tag{font-size:11px;letter-spacing:2px;text-transform:uppercase;color:#7f93ad}\n");
        h.append(".mini{height:6px;background:#0a1120;border-radius:4px;margin:10px 0 8px;overflow:hidden;border:1px solid #1e2a44}\n");
        h.append(".mini div{height:100%}\n");
        h.append(".nums{font-size:12px;color:#9fb3c8}\n");
        h.append("footer{text-align:center;color:#7f93ad;font-size:12px;padding:0 0 24px}\n");
        h.append("</style>\n</head>\n<body>\n");
        h.append("<header><h1>CODE<span>DNA</span></h1><div class='sub'>")
         .append(metrics.size()).append(metrics.size() == 1 ? " organism" : " organisms")
         .append(" &nbsp;·&nbsp; click a creature to open it</div></header>\n<div class='grid'>\n");

        for (int i = 0; i < metrics.size(); i++) {
            ASTParser.CodeMetrics m = metrics.get(i);
            CreatureGenerator.Creature c = creatures.get(i);
            String base = baseName(m);
            h.append("<a class='card' style='--c:").append(c.bodyGlow).append("' href='")
             .append(esc(base)).append("_DNA.html'>")
             .append("<img src='").append(esc(base)).append("_DNA.svg' alt='").append(esc(base)).append("'>")
             .append("<div class='info'><h3>").append(esc(base)).append("</h3>")
             .append("<span class='tag'>").append(esc(c.personality)).append(" · health ").append(c.healthScore).append("</span>")
             .append("<div class='mini'><div style='width:").append(Math.max(0, Math.min(100, c.healthScore)))
             .append("%;background:").append(c.auraColor).append("'></div></div>")
             .append("<div class='nums'>").append(m.methodCount).append(" methods · ")
             .append(m.loopCount).append(" loops · ").append(m.nestedLoopCount).append(" nested · ")
             .append(m.ifCount).append(" ifs</div></div></a>\n");
        }
        h.append("</div>\n<footer>Generated by CodeDNA</footer>\n</body>\n</html>");
        Files.writeString(Paths.get(outputPath), h.toString());
        return outputPath;
    }

    private static String buildHTML(ASTParser.CodeMetrics m,
                                    CreatureGenerator.Creature c,
                                    String svg,
                                    boolean withGalleryLink) {
        StringBuilder h = new StringBuilder();

        h.append("<!DOCTYPE html>\n<html lang='en'>\n<head>\n");
        h.append("<meta charset='UTF-8'>\n");
        h.append("<meta name='viewport' content='width=device-width, initial-scale=1'>\n");
        h.append("<title>CodeDNA — ").append(esc(m.fileName)).append("</title>\n");
        h.append("<style>\n").append(css(c)).append("</style>\n</head>\n<body>\n");

        // ── Header ───────────────────────────────────────────────
        h.append("<header>\n");
        if (withGalleryLink) h.append("  <a class='back' href='index.html'>&larr; all creatures</a>\n");
        h.append("  <h1>CODE<span>DNA</span></h1>\n");
        h.append("  <div class='sub'>").append(esc(m.fileName))
         .append(" &nbsp;·&nbsp; <b>").append(esc(c.personality)).append("</b></div>\n");
        h.append("</header>\n");

        h.append("<main>\n");

        // ── Creature ─────────────────────────────────────────────
        h.append("<section class='stage'>\n").append(svg).append("</section>\n");

        // ── Side panel ───────────────────────────────────────────
        h.append("<aside>\n");

        h.append("<div class='card'><p class='desc'>").append(esc(c.description)).append("</p>\n");
        h.append("<div class='chips'>");
        for (String t : c.traits) h.append("<span class='chip'>").append(esc(t)).append("</span>");
        h.append("</div></div>\n");

        h.append("<div class='card'><h2>Vital signs</h2>\n");
        h.append(bar("Health", c.healthScore, "var(--accent)"));
        h.append(bar("Complexity", c.complexityScore, "linear-gradient(90deg,#ffd93d,#ff6b6b)"));
        h.append("</div>\n");

        h.append("<div class='card'><h2>Code anatomy</h2><div class='stats'>\n");
        h.append(stat(m.totalLines,       "Total lines"));
        h.append(stat(m.codeLines,        "Code lines"));
        h.append(stat(m.commentLines,     "Comments"));
        h.append(stat(m.classCount,       "Classes"));
        h.append(stat(m.methodCount,      "Methods"));
        h.append(stat(m.loopCount,        "Loops"));
        h.append(stat(m.nestedLoopCount,  "Nested loops"));
        h.append(stat(m.ifCount,          "If statements"));
        h.append("</div></div>\n");

        h.append("<div class='card'><h2>Tentacles · methods</h2><ul class='methods'>\n");
        for (CreatureGenerator.Tentacle t : c.tentacles) {
            h.append("<li><span class='dot' style='background:").append(t.color).append("'></span>")
             .append("<span class='mname'>").append(esc(t.methodName)).append("()</span>")
             .append("<span class='mlines'>").append(t.methodLines).append(" lines</span></li>\n");
        }
        int hidden = m.methodNames.size() - c.tentacles.size();
        if (hidden > 0) {
            h.append("<li class='more'>+ ").append(hidden).append(" more methods</li>\n");
        }
        if (c.tentacles.isEmpty()) {
            h.append("<li class='more'>No methods found</li>\n");
        }
        h.append("</ul></div>\n");

        h.append("<div class='card'><h2>Legend</h2><ul class='legend'>\n");
        h.append(legend("#ffffff", "White nucleus", "class"));
        h.append(legend("#00e5ff", "Cyan cell", "loop"));
        h.append(legend("#bf80ff", "Purple cell", "if statement"));
        h.append(legend("#ff4060", "Red tumour", "nested loop"));
        h.append(legend("#ffd93d", "Yellow tentacle", "method > 20 lines"));
        h.append(legend("#ff6b6b", "Red tentacle", "method > 40 lines"));
        h.append("</ul></div>\n");

        h.append("</aside>\n</main>\n");
        h.append("<footer>Hover a tentacle to see its method · Generated by CodeDNA</footer>\n");
        h.append("</body>\n</html>");
        return h.toString();
    }

    // ── Small HTML pieces ────────────────────────────────────────
    private static String bar(String label, int value, String fill) {
        int v = Math.max(0, Math.min(100, value));
        return "<div class='bar'><div class='bl'><span>" + label + "</span><b>" + v + "/100</b></div>"
             + "<div class='track'><div class='fill' style='width:" + v + "%;background:" + fill + "'></div></div></div>\n";
    }

    private static String stat(int value, String label) {
        return "<div class='stat'><b>" + value + "</b><span>" + label + "</span></div>\n";
    }

    private static String legend(String color, String what, String meaning) {
        return "<li><span class='dot' style='background:" + color + "'></span>"
             + "<span>" + what + "</span><em>" + meaning + "</em></li>\n";
    }

    // ── Stylesheet ───────────────────────────────────────────────
    private static String css(CreatureGenerator.Creature c) {
        return String.format(Locale.ROOT,
            ":root{--accent:%s;--glow:%s;--bg:#070b14;--panel:rgba(15,22,38,0.85);--line:#1e2a44;--txt:#d7e2f0;--mute:#7f93ad}\n"
          + "*{box-sizing:border-box}\n"
          + "body{margin:0;min-height:100vh;color:var(--txt);font-family:'Consolas','Courier New',monospace;"
          +   "background:radial-gradient(ellipse at 40%% 25%%,#111c36 0%%,var(--bg) 70%%)}\n"
          + "header{text-align:center;padding:22px 16px 4px;position:relative}\n"
          + ".back{position:absolute;left:24px;top:28px;color:var(--mute);text-decoration:none;font-size:13px}\n"
          + ".back:hover{color:var(--glow)}\n"
          + "h1{margin:0;font-size:30px;letter-spacing:8px;font-weight:700}\n"
          + "h1 span{color:var(--glow);text-shadow:0 0 14px var(--glow)}\n"
          + ".sub{color:var(--mute);margin-top:6px;font-size:14px}\n"
          + ".sub b{color:var(--accent)}\n"
          + "main{display:grid;grid-template-columns:minmax(0,1fr) 340px;gap:20px;max-width:1300px;margin:0 auto;padding:16px 20px}\n"
          + ".stage{background:radial-gradient(circle at 50%% 45%%,rgba(255,255,255,0.03),transparent 65%%);"
          +   "border:1px solid var(--line);border-radius:16px;padding:8px}\n"
          + ".stage svg{width:100%%;height:auto;display:block}\n"
          + "aside{display:flex;flex-direction:column;gap:14px}\n"
          + ".card{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:14px 16px}\n"
          + ".card h2{margin:0 0 10px;font-size:12px;letter-spacing:3px;text-transform:uppercase;color:var(--mute)}\n"
          + ".desc{margin:0 0 10px;font-size:13px;line-height:1.5}\n"
          + ".chips{display:flex;flex-wrap:wrap;gap:6px}\n"
          + ".chip{font-size:11px;padding:3px 9px;border:1px solid var(--accent);border-radius:20px;color:var(--accent)}\n"
          + ".bar{margin-bottom:10px}\n"
          + ".bl{display:flex;justify-content:space-between;font-size:12px;margin-bottom:4px}\n"
          + ".track{height:9px;background:#0a1120;border-radius:6px;overflow:hidden;border:1px solid var(--line)}\n"
          + ".fill{height:100%%;border-radius:6px;box-shadow:0 0 10px var(--accent)}\n"
          + ".stats{display:grid;grid-template-columns:1fr 1fr;gap:8px}\n"
          + ".stat{background:#0a1120;border:1px solid var(--line);border-radius:8px;padding:8px 10px}\n"
          + ".stat b{display:block;font-size:20px;color:var(--glow)}\n"
          + ".stat span{font-size:11px;color:var(--mute)}\n"
          + "ul{list-style:none;margin:0;padding:0}\n"
          + ".methods{max-height:260px;overflow-y:auto}\n"
          + ".methods li,.legend li{display:flex;align-items:center;gap:8px;font-size:12px;padding:4px 0;border-bottom:1px solid #131c30}\n"
          + ".mname{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n"
          + ".mlines,.legend em{color:var(--mute);font-style:normal;font-size:11px;margin-left:auto}\n"
          + ".legend li span:nth-child(2){flex:0 1 auto}\n"
          + ".more{color:var(--mute);justify-content:center}\n"
          + ".dot{width:10px;height:10px;border-radius:50%%;flex:none;box-shadow:0 0 6px currentColor}\n"
          + "footer{text-align:center;color:var(--mute);font-size:12px;padding:6px 0 22px}\n"
          + "@media (max-width:900px){main{grid-template-columns:1fr}}\n",
            c.auraColor, c.bodyGlow);
    }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("'", "&#39;");
    }
}
