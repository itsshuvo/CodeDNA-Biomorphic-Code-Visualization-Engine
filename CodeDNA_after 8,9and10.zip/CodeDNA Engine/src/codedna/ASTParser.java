package codedna;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

/**
 * Reads a .java file and measures its structure (no external libraries).
 *
 * Weeks 4-5 : classes, methods, loops, ifs, comments, imports.
 * Week 10   : accuracy pass - keywords inside strings / comments are ignored,
 *             nesting and method lengths are tracked with real brace depth.
 */
public class ASTParser {

    // ── Result container ─────────────────────────────────────────
    public static class CodeMetrics {
        public String fileName;
        public List<String> classNames    = new ArrayList<>();
        public List<String> methodNames   = new ArrayList<>();
        public int totalLines;
        public int codeLines;
        public int commentLines;
        public int blankLines;
        public int methodCount;
        public int classCount;
        public int loopCount;       // for, while, do-while
        public int nestedLoopCount; // loops that sit inside another loop
        public int ifCount;
        public int tryCount;
        public int importCount;
        public int complexityScore; // 0-100
        public int healthScore;     // 0-100 (clean code indicator)
        public List<String> keywords = new ArrayList<>();
        public Map<String, Integer> methodLineCounts = new LinkedHashMap<>();
    }

    // ── Patterns ─────────────────────────────────────────────────
    private static final Pattern CLASS_DECL = Pattern.compile(
            "^(?:(?:public|protected|private|static|final|abstract|sealed|strictfp)\\s+)*(class|interface|enum)\\s+(\\w+)");

    // group1 = modifiers, group2 = return type (absent for constructors), group3 = name, group4 = { or ;
    private static final Pattern METHOD_DECL = Pattern.compile(
            "^((?:(?:public|protected|private|static|final|abstract|synchronized|native|strictfp|default)\\s+)*)"
          + "(?:<[^>]*>\\s+)?"
          + "([\\w.$]+(?:<.*?>)?(?:\\[\\])*\\s+)?"
          + "(\\w+)\\s*\\([^;{}]*\\)\\s*(?:throws\\s+[\\w.$,\\s]+)?\\s*(?:([{;]).*)?$");

    private static final Pattern NOT_A_METHOD = Pattern.compile(
            "^(?:return|new|else|if|for|while|switch|catch|try|do|throw|case|assert|break|continue|super|this)\\b");
    private static final Pattern FOR_WHILE = Pattern.compile("\\b(?:for|while)\\s*\\(");
    private static final Pattern DO_LOOP   = Pattern.compile("(?:^|[;{}])\\s*do\\s*(?:\\{|$)");
    private static final Pattern DO_TAIL   = Pattern.compile("^\\}\\s*while\\s*\\(.*\\)\\s*;$");
    private static final Pattern IF        = Pattern.compile("\\bif\\s*\\(");
    private static final Pattern TRY       = Pattern.compile("\\btry\\s*[({]");
    private static final Set<String> BAD_NAMES = new HashSet<>(Arrays.asList(
            "if", "for", "while", "switch", "catch", "synchronized", "return", "new", "super", "this"));

    // ── Helper types ─────────────────────────────────────────────
    private static class LoopFrame {
        final int startDepth;
        boolean opened;
        LoopFrame(int startDepth) { this.startDepth = startDepth; }
    }

    /** Removes comments and blanks out string / char contents, remembering multi-line state. */
    private static class LineCleaner {
        boolean inBlockComment = false;
        boolean inTextBlock    = false;

        String clean(String line) {
            boolean startedInText = inTextBlock;
            StringBuilder out = new StringBuilder();
            int i = 0, n = line.length();
            while (i < n) {
                char ch = line.charAt(i);
                char nx = (i + 1 < n) ? line.charAt(i + 1) : '\0';

                if (inBlockComment) {
                    if (ch == '*' && nx == '/') { inBlockComment = false; i += 2; } else i++;
                    continue;
                }
                if (inTextBlock) {
                    if (line.startsWith("\"\"\"", i)) { inTextBlock = false; i += 3; out.append("\"\""); }
                    else if (ch == '\\') i += 2;
                    else i++;
                    continue;
                }
                if (ch == '/' && nx == '/') break;                                 // rest is a comment
                if (ch == '/' && nx == '*') { inBlockComment = true; i += 2; continue; }
                if (line.startsWith("\"\"\"", i)) { inTextBlock = true; i += 3; out.append("\"\""); continue; }
                if (ch == '"' || ch == '\'') {                                     // string / char literal
                    out.append(ch).append(ch);
                    i++;
                    while (i < n) {
                        char d = line.charAt(i);
                        if (d == '\\') i += 2;
                        else if (d == ch) { i++; break; }
                        else i++;
                    }
                    continue;
                }
                out.append(ch);
                i++;
            }
            if (startedInText && out.length() == 0) out.append("\"\"");            // text-block body is code, not a comment
            return out.toString();
        }
    }

    // ── Main parse entry point ───────────────────────────────────
    public static CodeMetrics parse(String filePath) throws IOException {
        CodeMetrics m = new CodeMetrics();
        m.fileName = Paths.get(filePath).getFileName().toString();

        List<String> lines = Files.readAllLines(Paths.get(filePath));
        m.totalLines = lines.size();

        LineCleaner cleaner = new LineCleaner();
        List<LoopFrame> loops = new ArrayList<>();
        int braceDepth = 0;

        // current method
        boolean inMethod = false, methodOpened = false;
        int methodStartDepth = 0, methodStartCode = 0;
        String methodKey = null;

        for (String raw : lines) {
            if (raw.trim().isEmpty()) { m.blankLines++; continue; }

            String code = cleaner.clean(raw);
            String t = code.trim();
            if (t.isEmpty()) { m.commentLines++; continue; }

            m.codeLines++;
            boolean justDetected = false;

            // ── imports / classes
            if (t.startsWith("import ")) m.importCount++;
            Matcher cm = CLASS_DECL.matcher(t);
            if (cm.find()) {
                m.classCount++;
                m.classNames.add(cm.group(2));
            }

            // ── methods (only looked for outside method bodies)
            if (!inMethod) {
                String head = t.replaceFirst("^(?:@\\w+(?:\\([^)]*\\))?\\s*)+", "");
                int paren = head.indexOf('(');
                // a '=' before the '(' means a field initialiser or lambda, e.g.  int x = foo(1);
                if (paren > 0 && !head.substring(0, paren).contains("=")
                        && !NOT_A_METHOD.matcher(head).find()) {
                    Matcher mm = METHOD_DECL.matcher(head);
                    if (mm.matches() && !BAD_NAMES.contains(mm.group(3))) {
                        String mods = mm.group(1), type = mm.group(2), term = mm.group(4);
                        boolean ok = "{".equals(term)
                                  || (";".equals(term) && type != null)
                                  || (term == null && (type != null || !mods.isEmpty()));
                        if (ok) {
                            String name = mm.group(3);
                            String key = name;
                            for (int k = 2; m.methodLineCounts.containsKey(key); k++) key = name + "#" + k;
                            m.methodCount++;
                            m.methodNames.add(key);
                            m.methodLineCounts.put(key, 1);
                            if (!";".equals(term)) {
                                inMethod = true;
                                methodOpened = false;
                                methodStartDepth = braceDepth;
                                methodStartCode  = m.codeLines - 1;
                                methodKey = key;
                                justDetected = true;
                            }
                        }
                    }
                }
            }

            // ── loops (a loop that starts while another is open = nested)
            boolean isLoop = DO_LOOP.matcher(t).find()
                          || (FOR_WHILE.matcher(t).find() && !DO_TAIL.matcher(t).matches());
            if (isLoop) {
                m.loopCount++;
                if (!loops.isEmpty()) m.nestedLoopCount++;
                loops.add(new LoopFrame(braceDepth));
            }

            // ── ifs / try
            Matcher im = IF.matcher(t);
            while (im.find()) m.ifCount++;
            if (TRY.matcher(t).find()) m.tryCount++;

            // ── braces
            int opens = 0, closes = 0;
            for (int i = 0; i < t.length(); i++) {
                char ch = t.charAt(i);
                if (ch == '{') opens++; else if (ch == '}') closes++;
            }
            braceDepth = Math.max(0, braceDepth + opens - closes);

            // loop bookkeeping: a loop ends when its braces close (or its single statement ends)
            for (LoopFrame f : loops) if (!f.opened && opens > 0) f.opened = true;
            while (!loops.isEmpty()) {
                LoopFrame f = loops.get(loops.size() - 1);
                if (f.opened && braceDepth <= f.startDepth)       loops.remove(loops.size() - 1);
                else if (!f.opened && t.endsWith(";"))            loops.remove(loops.size() - 1);
                else break;
            }

            // method bookkeeping
            if (inMethod) {
                if (!methodOpened && opens > 0) methodOpened = true;
                if (methodOpened && braceDepth <= methodStartDepth) {
                    m.methodLineCounts.put(methodKey, m.codeLines - methodStartCode);
                    inMethod = false;
                    loops.clear();
                } else if (!methodOpened && !justDetected && !t.startsWith("throws")) {
                    // it never got a body, so it was not a method after all
                    m.methodCount--;
                    m.methodNames.remove(methodKey);
                    m.methodLineCounts.remove(methodKey);
                    inMethod = false;
                }
            }
        }

        // ── Complexity score (0-100)
        int complexity = 0;
        complexity += Math.min(30, m.methodCount * 3);
        complexity += Math.min(20, m.loopCount   * 4);
        complexity += Math.min(20, m.ifCount      * 2);
        complexity += Math.min(15, m.nestedLoopCount * 10);
        complexity += Math.min(10, m.classCount   * 5);
        complexity += Math.min(5,  m.tryCount     * 2);
        m.complexityScore = Math.min(100, complexity);

        // ── Health score (0-100): comments help, nesting and huge classes hurt
        int health = 60;
        if (m.totalLines > 0) {
            double commentRatio = (double) m.commentLines / m.totalLines;
            health += (int) (commentRatio * 30);
        }
        health -= m.nestedLoopCount * 8;
        health -= Math.max(0, m.methodCount - 10) * 2;
        m.healthScore = Math.max(5, Math.min(100, health));

        m.keywords = extractKeywords(lines);
        return m;
    }

    // ── Most-used identifiers ────────────────────────────────────
    private static List<String> extractKeywords(List<String> lines) {
        Map<String, Integer> freq = new HashMap<>();
        Pattern word = Pattern.compile("\\b([a-zA-Z][a-zA-Z0-9]{3,})\\b");
        Set<String> skip = new HashSet<>(Arrays.asList(
                "public","private","protected","static","void","class",
                "return","import","package","this","super","new","null",
                "true","false","else","extends","implements","interface",
                "final","abstract","String","List","Map","int","boolean"
        ));
        for (String line : lines) {
            Matcher m = word.matcher(line.trim());
            while (m.find()) {
                String w = m.group(1);
                if (!skip.contains(w)) freq.merge(w, 1, Integer::sum);
            }
        }
        return freq.entrySet().stream()
                .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
                .limit(6)
                .map(Map.Entry::getKey)
                .collect(java.util.stream.Collectors.toList());
    }
}
