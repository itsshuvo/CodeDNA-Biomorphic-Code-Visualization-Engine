/**
 * CleanCode - a small, well documented utility class.
 *
 * Every method has a short comment, there are no nested loops and the
 * logic is easy to follow. CodeDNA should turn this into a healthy,
 * blue "Elegant" organism.
 *
 * Why this file is "healthy":
 *   1. Plenty of comments explain what each method does.
 *   2. Methods are short and do exactly one job.
 *   3. There are no nested loops (nested loops become red tumours).
 *   4. The control flow is simple: one loop and one if statement.
 *
 * Try changing this file - remove the comments or add nested loops -
 * and generate the organism again to watch it get sicker.
 *
 * How the numbers are used:
 *   - comments raise the health score (well documented = healthier)
 *   - nested loops lower it (each one is a red tumour on the creature)
 *   - very large classes lower it a little (too many methods)
 * A high health score gives a blue body, a cyan aura and the
 * personality "Elegant".
 */
public class CleanCode {

    // ---------------------------------------------------------------
    // Adds two numbers together.
    // ---------------------------------------------------------------
    public static int add(int a, int b) {
        return a + b;
    }

    // ---------------------------------------------------------------
    // Returns the larger of two numbers.
    // ---------------------------------------------------------------
    public static int max(int a, int b) {
        // pick the bigger value
        if (a > b) {
            return a;
        }
        return b;
    }

    // ---------------------------------------------------------------
    // Adds up every value in the array.
    // ---------------------------------------------------------------
    public static int sum(int[] values) {
        int total = 0;
        // one simple loop, no nesting
        for (int v : values) {
            total += v;
        }
        return total;
    }

    // ---------------------------------------------------------------
    // Returns true when the number is even.
    // ---------------------------------------------------------------
    public static boolean isEven(int n) {
        return n % 2 == 0;
    }

    // ---------------------------------------------------------------
    // Program entry point: prints a few results.
    // ---------------------------------------------------------------
    public static void main(String[] args) {
        int[] data = {4, 8, 15, 16, 23, 42};
        System.out.println("Sum  : " + sum(data));
        System.out.println("Max  : " + max(3, 9));
        System.out.println("Even : " + isEven(10));
    }
}
