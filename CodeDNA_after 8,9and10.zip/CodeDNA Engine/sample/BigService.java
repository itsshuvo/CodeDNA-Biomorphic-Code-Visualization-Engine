import java.util.*;
import java.io.*;
import java.nio.file.*;
import java.time.*;
import java.util.regex.*;
import java.util.stream.*;

/**
 * BigService - lots of small methods, like a typical service class.
 *
 * The class keeps a named counter for each key and can:
 *   - count things:      increment(), get(), has(), total(), busiest()
 *   - list and search:   keys(), matches(), filter()
 *   - save and restore:  save(), load()
 *   - describe itself:   report()
 *   - keep a log:        logMessage(), logSize(), clearLog()
 *
 * It has more methods than one creature has tentacles, so only the
 * first sixteen are drawn as tentacles and the rest are listed in the
 * side panel of the generated page.
 *
 * Usage:
 *   BigService s = new BigService();
 *   s.start();
 *   s.increment("alpha");
 *   System.out.println(s.report());
 *   s.stop();
 */
public class BigService {

    private final Map<String, Integer> counters = new HashMap<>();
    private final List<String> log = new ArrayList<>();

    public BigService() {
        log.add("created");
    }

    // Start.
    public void start()   { log.add("start"); }
    // Stop.
    public void stop()    { log.add("stop"); }
    // Reset.
    public void reset()   { counters.clear(); }

    // Increment.
    public int increment(String key) {
        int next = counters.getOrDefault(key, 0) + 1;
        counters.put(key, next);
        return next;
    }

    // Get.
    public int get(String key) {
        return counters.getOrDefault(key, 0);
    }

    // Has.
    public boolean has(String key) {
        return counters.containsKey(key);
    }

    // Keys.
    public List<String> keys() {
        List<String> result = new ArrayList<>(counters.keySet());
        Collections.sort(result);
        return result;
    }

    // Total.
    public int total() {
        int sum = 0;
        for (int v : counters.values()) {
            sum += v;
        }
        return sum;
    }

    // Busiest.
    public String busiest() {
        String best = null;
        int bestCount = -1;
        for (Map.Entry<String, Integer> e : counters.entrySet()) {
            if (e.getValue() > bestCount) {
                best = e.getKey();
                bestCount = e.getValue();
            }
        }
        return best;
    }

    // Save.
    public void save(String file) throws IOException {
        List<String> lines = new ArrayList<>();
        for (String k : keys()) {
            lines.add(k + "=" + counters.get(k));
        }
        Files.write(Paths.get(file), lines);
    }

    // Load.
    public void load(String file) throws IOException {
        for (String line : Files.readAllLines(Paths.get(file))) {
            String[] parts = line.split("=");
            if (parts.length == 2) {
                counters.put(parts[0], Integer.parseInt(parts[1]));
            }
        }
    }

    // Report.
    public String report() {
        StringBuilder sb = new StringBuilder();
        sb.append("Report at ").append(LocalDateTime.now()).append("\n");
        for (String k : keys()) {
            sb.append(k).append(" -> ").append(get(k)).append("\n");
        }
        return sb.toString();
    }

    // Matches.
    public boolean matches(String key, String regex) {
        return Pattern.compile(regex).matcher(key).find();
    }

    // Filter.
    public List<String> filter(String regex) {
        return keys().stream().filter(k -> matches(k, regex)).collect(Collectors.toList());
    }

    // Log message.
    public void logMessage(String message) { log.add(message); }
    // Log size.
    public int  logSize()                  { return log.size(); }
    // Clear log.
    public void clearLog()                 { log.clear(); }

    // Safe increment.
    public void safeIncrement(String key) {
        try {
            increment(key);
        } catch (Exception e) {
            log.add("failed: " + key);
        }
    }

    // Main.
    public static void main(String[] args) throws IOException {
        BigService s = new BigService();
        s.start();
        s.increment("alpha");
        s.increment("beta");
        s.increment("alpha");
        System.out.println(s.report());
        s.stop();
    }
}
