/** MultiClass - several small types in one file (many classes = a bigger nucleus). */
public class MultiClass {

    interface Shape {
        double area();
    }

    static class Circle implements Shape {
        private final double r;
        Circle(double r) { this.r = r; }
        public double area() { return Math.PI * r * r; }
    }

    static class Square implements Shape {
        private final double s;
        Square(double s) { this.s = s; }
        public double area() { return s * s; }
    }

    enum Size { SMALL, LARGE }

    static Size classify(Shape shape) {
        if (shape.area() > 50) {
            return Size.LARGE;
        }
        return Size.SMALL;
    }

    public static void main(String[] args) {
        Shape[] shapes = { new Circle(2), new Square(9) };
        for (Shape s : shapes) {
            System.out.println(s.area() + " " + classify(s));
        }
    }
}
