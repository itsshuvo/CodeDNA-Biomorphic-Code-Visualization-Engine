public class MessyCode {

    static int[][] grid = new int[10][10];

    public static void fillGrid() {
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                for (int k = 0; k < 3; k++) {
                    grid[i][j] += i * j + k;
                }
            }
        }
    }

    public static int countBig() {
        int c = 0;
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                if (grid[i][j] > 20) {
                    c++;
                }
            }
        }
        return c;
    }

    public static void printGrid() {
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                System.out.print(grid[i][j] + " ");
            }
            System.out.println();
        }
    }

    public static void a1() { int x = 1; }
    public static void a2() { int x = 2; }
    public static void a3() { int x = 3; }
    public static void a4() { int x = 4; }
    public static void a5() { int x = 5; }
    public static void a6() { int x = 6; }
    public static void a7() { int x = 7; }
    public static void a8() { int x = 8; }
    public static void a9() { int x = 9; }

    public static void hugeMethod(int n) {
        int total = 0;
        try {
            total += n;
            total += n * 2;
            total += n * 3;
            total += n * 4;
            total += n * 5;
            total += n * 6;
            total += n * 7;
            total += n * 8;
            total += n * 9;
            total += n * 10;
            total += n * 11;
            total += n * 12;
            total += n * 13;
            total += n * 14;
            total += n * 15;
            total += n * 16;
            total += n * 17;
            total += n * 18;
            total += n * 19;
            total += n * 20;
            total += n * 21;
            total += n * 22;
            total += n * 23;
            total += n * 24;
            total += n * 25;
            total += n * 26;
            total += n * 27;
            total += n * 28;
            total += n * 29;
            total += n * 30;
            total += n * 31;
            total += n * 32;
            total += n * 33;
            total += n * 34;
            total += n * 35;
            total += n * 36;
            total += n * 37;
            total += n * 38;
            total += n * 39;
            total += n * 40;
            total += n * 41;
            total += n * 42;
        } catch (Exception e) {
            total = -1;
        }
        System.out.println(total);
    }

    public static void main(String[] args) {
        fillGrid();
        System.out.println(countBig());
        printGrid();
        hugeMethod(3);
    }
}
